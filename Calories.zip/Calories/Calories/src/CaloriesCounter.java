//adds calories as you eat
import java.util.Scanner;

public class CaloriesCounter {
	int total = 0;
	int goal = 0;
	
	public CaloriesCounter(int goal){
		this.goal = goal;
	}
	
	public int getTotal(){
		getBreakfastTotal();
		getLunchTotal();
		getSupperTotal();
		System.out.printf("Total calories is %d.", total);
		System.out.println();
		return total;
		
	}
	
	public int getGoal(){
		goal -= total;
		System.out.printf("Total goal calories remaining is %d.", goal);
		return goal;
	}
	
	public int getBreakfastTotal(){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter breakfast calories. ");
		int breakfastCals = input.nextInt();
		total += breakfastCals;
		return total;
	}
	
	public int getLunchTotal(){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter lunch calories. ");
		int lunchCals = input.nextInt();
		total += lunchCals;
		return total;
	}
	
	public int getSupperTotal(){
		Scanner input = new Scanner(System.in);
		System.out.println("Enter breakfast calories. ");
		int supperCals = input.nextInt();
		total += supperCals;
		return total;
	}
}
