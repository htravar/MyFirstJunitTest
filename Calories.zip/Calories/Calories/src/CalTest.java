
public class CalTest {

	public static void main(String[] args) {
		CaloriesCounter newC = new CaloriesCounter(1500);
		
		//don't call getBreakfastTotal - getTotal calls it for you
		newC.getTotal();
		newC.getGoal();
	}

}
