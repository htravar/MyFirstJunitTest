import static org.junit.Assert.*;

import org.junit.Test;


public class CaloriesCounterTest {
	
	@Test
	public void testTotal(){
		CaloriesCounter c = new CaloriesCounter(1500);//pass goal number
		assertEquals("Message", 1500, c.getTotal());
		
	}

}
